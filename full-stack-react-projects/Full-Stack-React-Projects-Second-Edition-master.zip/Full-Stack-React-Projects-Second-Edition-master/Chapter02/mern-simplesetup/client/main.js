import React from 'react'
import { render } from 'react-dom'
import HelloWorld from './HelloWorld'


render(<HelloWorld/>, document.getElementById('root'))
